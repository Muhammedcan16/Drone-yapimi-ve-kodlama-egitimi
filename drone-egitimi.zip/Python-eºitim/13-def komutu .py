#def komutu kendi fonksiyonumuzu oluşturmamızı sağlıyor
def toplama():
    toplama = 8+2 
    print(toplama)

toplama()    

