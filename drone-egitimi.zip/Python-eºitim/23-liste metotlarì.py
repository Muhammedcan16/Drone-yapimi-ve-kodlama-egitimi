liste = ['python',15, 15.9,89]
liste.append('Yazılım') #eklemek için kullanılır
print(liste)
liste.remove('python')#çıkarmak için 
print(liste)

print(100*'=')

liste2 = liste #liste3 ün farklı olmasının sebebi bu 
liste3 = liste.copy()

print('1.liste',liste)
print('2.liste',liste2)
print('3.liste',liste3)

print(100*'=')

liste.append('mami')
liste.remove(15.9)

print('1.liste',liste)
print('2.liste',liste2)
print('3.liste',liste3)

print(100*'=')

print(liste.count('python'))#kaçtane var onu söylüyor

a = [12,21,32,54,6,56,7,78787,89]
a.sort() #küçükten büyüye sıralıyor
print(a)

b = ['tarık','istanbul','yazılım']
b.sort()#alfabetik olarak sıralıyor
print(b)

c = int(liste.index('89')) # listede kaçıncı sırada olduğunu buluyor index
c += 1
print(c)


