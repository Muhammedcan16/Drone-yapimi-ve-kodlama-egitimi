a = ('öğreniyorum')
b = ('yapayzeka')

c = ('yapayzeka')
d = ('öğreniyorum')


print (b,a,sep=' ') #sep koutu ile virgülleri değiştirebiliyorum
print (b,a,sep='9')
print (b,a,end = ';') #sonuna ne koymak istiyorsak onu belirlerim
print('--------------------')
print(c,d)
print (c,'\n',d) #diğer değeri alt satıra yazıyor
print('--------------------')

isim = ('Muhammedcan')
soyisim = ('Özcan')
hobi =('Müzik dinlemek')
felsefe = ('Başarmak')

print ('isim = ',isim ,'\n','soyisim = ',soyisim,'\n','hobi=',hobi,'\n','felsefe=',felsefe)