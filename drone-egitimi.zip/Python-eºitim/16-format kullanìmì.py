#format fonksiyonu stringlerimizi yönetmemizi sağlıyor
a = '''
Bursa : iskender
Denizli: {}
Kırşehir: {}
'''.format('pamukkale','ahi evran')
print(a)

print('----------------------')

b = '123456789'
for c in b:
    print('Hayata {} - 10 geride başladık'.format(c))
    #print('hayata', c, '- 10 geride başladık')

print('----------------------')

d = 'yazılım'
e = 'python'
g = 'öğreniyorum'
h= 14
f ='{},{},{}'.format(d,e,g)
#f ='{0},{1},{2}'.format(d,e,g)
print(f)

print('----------------------')


t = '|{:>50}|'.format(d) #içine yazdığınız değer kadar boşluk bırakacak
print(t)
print()
r ='|{:<s}|'.format(d)   #içine s yazıyorsam str,  d yazarsam int
print(r)

o ='|{:<d}|'.format(h)   #içine s yazıyorsam str,  d yazarsam int
print(o)
