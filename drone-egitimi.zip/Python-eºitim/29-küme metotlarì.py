kume = {'python', 12,78}
kume2= {'yazılım','mami',78,76.8}
print(type(kume)) #set--> kume

kume.add('yazılım') #eklemek
print(kume)

kume.remove('python') #çıkart ve eğer o eleman yoksa hata verir
print(kume)

print('---------------')

kume.discard('mami') #varsa çıkart yoksa hata vermez
print(kume)

print(50*'-')
print(kume)
print(kume2)
print(kume.difference(kume2))#kume fark kume2
print(kume2.difference(kume))#kume2 fark kume
print('---------------')
print(kume.symmetric_difference(kume2))#ortak olanlar hariç hepsini yazdır
print(kume.intersection(kume2))#ortak olanları alır
print(kume.isdisjoint(kume2))#birebir aynısı mı diye bakılıyor
