#toplama, çıkarma, çarpma, bölme, üs alma
print (5+5)
print (5-3)
print (5*2)
print (10/3) #kalanlı
print (10//3) #kalansız
print (5**2) #üs alma

print (10.2/2)
print('y'+'y')
#print('y'-'y') #olmaz mantığı yok
print('y'*3)
#print('y'/2) #çıkarma olmadığına göre mantıken bölme de olmaz
print('------------------------------------------')

a = 12
b = 12.1
c = '12'

print(5+a)
print(5-a)
print(5*a)
print(5/a)
print(5//a)
print(5**a)

#print(5+c)
print(5*c) #c değerini yan yana 5 defa yazacak aslında olay şu cxcxcxcxc gibi 

print('------------------------------------------')

d = a*b
print(a*b)
