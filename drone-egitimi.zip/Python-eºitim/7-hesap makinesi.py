#hesap makinesi
a = float(input('sayı 1 giriniz:'))
b = float(input('sayı 2 giriniz:'))

print('sayı 1:',a,'sayı 2:',b)

print('''
1-Toplama
2-Çıkarma
3-Çarpma
4-Bölme
5-Üssü Alma
6-Tüm İşlemleri Uygulasın
   ''')

c = int(input('Yapmak istediğiniz işlemi seçiniz:'))

if c == 1 :
  print(a+b)
elif c == 2 : 
  print == (a-b)
elif c == 3 : 
  print == (a*b)
elif c == 4 : 
  print == (a/b)
elif c == 5 : 
  print == (a**b)
elif c == 6 : 
  print  (a+b ,a-b ,a*b,a/b,a**b)
else:
    print('İşlem seçimini yanlış yaptınız.')

