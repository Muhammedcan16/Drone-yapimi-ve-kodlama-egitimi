#and , or --->  ve , veya

nick = input('kullanıcı adı giriniz:')
sifre = input('şifre giriniz:')

a = ('mami')
b = ('mami1')

if nick == (a) and sifre == (b):
    print('Giriş başarılı')

elif nick == (a) or sifre != (b):
    print('Kullanıcı adı doğru , şifre yanlış')

elif nick != (a) or sifre == (b):
    print('Kullanıcı adı yanlış , şifre doğru')
else:
    print('giriş başarısız')
