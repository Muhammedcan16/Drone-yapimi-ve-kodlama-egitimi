#demet metotları 

demet = ('python','yazılım',56,56.7,56,56,56)
print(type(demet))

print(demet.index('yazılım')) #kaçıncı sırada olduğunu yazdırıyor
print(demet.index(56))

print(demet.count(56))#kaç tane olduğunu yazıyor