#orta veri tipleri                       -------->int,str,float temel veri tipleridir.
#liste   list

liste = ['Yazılım', 23, 23.5]
liste += ['98', 87]
print(liste)
for a in liste:
    print(a)

print('----------------')

sehirler = ['bursa', 'ankara', 'kırşehir']
sehir = input('eklemek istediğiniz şehri yazınız:')
sehirler += [sehir]
for b in sehirler:
    print (b) 