#orta veri tipi 
#sözlük

sözlük = {'Irak':'Uzak', 'Yaş':'21'}
print(sözlük['Irak'])
print(sözlük['Yaş'])

print('____________')
print()

ornek ={'İsim':'mami', 'doğum':'bursa', 'yaş':'20'}
print(ornek['İsim'])
print(ornek['doğum'])
print(ornek['yaş'])

