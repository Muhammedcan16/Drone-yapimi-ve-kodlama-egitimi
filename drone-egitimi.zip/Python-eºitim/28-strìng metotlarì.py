#string metotları ileriseviye stringler

str = 'Python Yazılım Dilini seviyoruz'

a = str.replace('i','ı') #harfleri değiştiriyor
print(a)

a = str.split() #liste tipine çeviriyor
print(a)

a = str.split('i') #i lerin olduğu yerlerden böldü
print(a)

a = str.split('i',1) #ilk i den böl başka i lerden bölme
print(a)

a = str.rsplit('i',1) #sondan başlayarak ilk i den böl başka i lerden bölme  
print(a)
#python 0 dan saymaya başlar o yüzden 2 tane siler

print('Muhammedcan Özcan'.lower()) #hepsini küçük harf yapıyor
print('Muhammedcan Özcan'.upper()) #hepsini büyük harf yapıyor
print('muhammedcan özcan'.islower()) #hepsinin küçük harf olmaması durumunda hata veriyor 
print('muhammedcan özcan'.isupper()) #hepsinin büyük harf olmaması durumunda hata veriyor 



