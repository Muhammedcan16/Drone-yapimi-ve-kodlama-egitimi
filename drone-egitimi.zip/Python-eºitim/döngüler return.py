#dobuler return
a = float(input('1.sayıyı giriniz:'))
b = float(input('2.sayıyı giriniz:'))

def hesap (a,b,):
    toplama = a+b
    return(toplama)
print(hesap(a,b))


