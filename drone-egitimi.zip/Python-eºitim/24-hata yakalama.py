a = float(input('bölünen değeri girirniz:'))
b = float(input('bölen değeri giriniz:'))

try:
    print(a/b)

#except: 
#    print('Bir hata oluştu.')

except ZeroDivisionError:
    print('Bir sayının sıfıra bölümü tanımsızdır.')

except TypeError:
    print('veri tipinden kaynaklı bir hata alındı.')

finally:
    print('\nMami')