#tuple veri tipi  liste veri tipinin nerdeyse aynısı

liste = ['python',12,23.5]
demet = ('python',12,23.5) #1 den fazla değere sahip olabilir diyor 

print(type(liste))
print(type(demet))
 
#liste büyük verileri işlerken 10gb veri tabanlarında kullanılır
#demet küçük işler için 2,3 gb veri tabanlarında kullanılır

liste += ['yazılım']
demet += ('yazılım')

print(liste)
#print(demet) #hata alır str algılar 
