#kullanıcıdan veri almak
a = input('Adınızı giriniz:')
print(a)

b = float(input('Sayı 1 :'))
c = float(input('sayı 2 :'))
print('toplamları:',b+c)
print('farkları:',b-c)
print('çarpımları:',b*c)
print('bölümleri:',b/c)
print('Birinci sayı üssü ikinci sayı:',b**c)