# in ve not in
sifre = input('Şifrenizi giriniz:')


if 'abc' in sifre :
    print ('şifrenizin içinde abc geçiyor')
elif 'a' and 'b' in sifre :
    print ('a ve b var')
elif 'c' or 'd' not in sifre:
    print('c veya d şifrede yok')    
elif 'abc' not in sifre :
    print ('şifrenizde abc bulunmuyor')
