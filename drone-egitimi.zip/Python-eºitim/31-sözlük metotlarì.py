#sözlük metotları

sozluk = {'siyah':'kara', 'beyaz':'ak', 'al':'kırmızı'}
#a = dict()

giris = input('eş anlamlısını görmek istediğiniz kelimeyi girin:') #girilen eş anlamlısını yaz
#print(sozluk[giris])

print(sozluk.get(giris,'Tanımsız yazı girdiniz')) #hata yönetimi
 
print(50*'-')

sözlük = {'siyah':'kara', 'beyaz':'ak', 'al':'kırmızı'}
for a in sözlük.items(): # kümede ne varsa yaz
    print(a) 

for a in sözlük.keys(): #ilk kelimeler
    print(a)

for a in sözlük.values(): # ikinci kelimeler
    print(a)    


