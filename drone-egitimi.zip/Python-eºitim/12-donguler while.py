#donguler while 
# while true olduğu zaman sonsuza kadar devam eder kapatma kodu yazıolmamışsa

#while True:
#    print('mami')

a = int(input('sayı giriniz:'))
while a < 10:
   a += 1
   print('mami')

#-ken yani mesela girilen sayı 10dan küçükken girilen sayıya 10 olaba kadar 1 ekleyerek istenilen değeri yaz