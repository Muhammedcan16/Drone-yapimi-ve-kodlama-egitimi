#liste veri tip 2
liste =['python','merhaba',132,12.3,['yazılım',124,12.4]]

print(liste[1][2])#listedeki 1. ögenin 3. karakteri

str = 'Muhammedcan'
print(str[3])