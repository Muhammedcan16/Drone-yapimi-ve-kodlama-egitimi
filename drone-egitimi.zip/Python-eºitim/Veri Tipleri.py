a = 1265 #int
b = 12,5 #float
c = 'merhaba' #string tırnak içinde kullanılır 

print (a,b,c)