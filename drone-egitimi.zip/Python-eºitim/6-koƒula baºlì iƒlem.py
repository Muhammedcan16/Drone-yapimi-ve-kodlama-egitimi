#if  #eğer
#elif #if deki değilse
#else #hiçbir koşul sağlanmazsa

sayi = float(input('Sayı yazınız:'))

if sayi > 5:
    print ('5 den büyük sayı yazdınız')

elif sayi < 5:
   print ('5 den küçük sayı yazdınız')

else:
    print (sayi,'beşe eşittir.')

print('--------------------')

print('''
1-Bursa
2-İstanbul
3-Ankara''')

secim = float(input('Bir şehir seçiniz='))

if secim == 1:
    print ('Bursa')
elif secim == 2:
    print ('İstanbul')
elif secim == 3:
    print ('Ankara') 
else:
    print('yanlış yazdınız')           





