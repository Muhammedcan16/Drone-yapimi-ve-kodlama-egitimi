#tekrar ve örnek
import os 
os.system("cls") #temiz bir ekran sağlıyor

kitap_liste = list()
menü = ('''
1-Kitap Ekle
2-Kitap Çıkar
3-Kitapları Listele
Q-Çıkış
''')

def kitapekle(liste,kitap):
    liste += [kitap]
    print('{} adlı kitap başarıyla listeye eklendi.'.format(kitap))
    input('Ana menüye dönmek için ENTER tuşuna basınız:')

def kitapcikar():
    pass


def listele(kitap_liste):
    for a in kitap_liste:
        print('Kitap adı ===> {}'.format(a)) 
        input('Ana menüye dönmek için ENTER tuşuna basınız:')   

def cikis():
    quit()
    
while True:
    os.system('cls')
    print(menü)
    secim = input('Yapmak istediğiniz işlemin numarasını yazınız:')

    if secim == '1' :
        kitap_adi = input('Eklemek istediğiniz kitabın adını yazınız:')
        kitapekle(kitap_liste,kitap_adi)

    elif secim == '2' :
        kitapcikar()

    elif secim == '3' :
        listele(kitap_liste)

    elif secim == 'q' or secim =='Q':
        cikis=()
    
    else:
        print('Hatalı seçim yaptınız.')
        input('Ana menüye dönmek için ENTER tuşuna basınız:')  

        